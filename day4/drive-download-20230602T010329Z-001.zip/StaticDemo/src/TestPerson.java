import java.util.Date;

public class TestPerson {
public static void main(String[] args) {
	Person p=new Person("xxx","33333",new Date());
	Person p1=new Person("yyyy","22222",new Date());
	System.out.println(p);
	System.out.println(p1);
}
}
