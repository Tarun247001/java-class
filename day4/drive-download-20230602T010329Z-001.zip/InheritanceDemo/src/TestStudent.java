
public class TestStudent {

	public static void main(String[] args) {
		Student s=new Student();
		Student s1=new Student("s","Rajan","3333",99,98,97);
		System.out.println(s1);

	}

}
